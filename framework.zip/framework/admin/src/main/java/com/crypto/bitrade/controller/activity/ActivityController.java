package com.bizzan.bitrade.controller.activity;

import static org.springframework.util.Assert.notNull;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import com.bizzan.bitrade.entity.*;
import com.bizzan.bitrade.service.*;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.bizzan.bitrade.annotation.AccessLog;
import com.bizzan.bitrade.constant.AdminModule;
import com.bizzan.bitrade.constant.BooleanEnum;
import com.bizzan.bitrade.constant.PageModel;
import com.bizzan.bitrade.constant.SysConstant;
import com.bizzan.bitrade.constant.TransactionType;
import com.bizzan.bitrade.controller.common.BaseAdminController;
import com.bizzan.bitrade.util.DateUtil;
import com.bizzan.bitrade.util.MessageResult;
import com.bizzan.bitrade.vendor.provider.SMSProvider;
import com.sparkframework.security.Encrypt;

@RestController
@RequestMapping("activity/activity")
public class ActivityController extends BaseAdminController {
    @Autowired
    private ActivityService activityService;

    @Autowired
    private ActivityOrderService activityOrderService;

    @Autowired
    private MemberWalletService memberWalletService;

    @Autowired
    private MemberService memberService;

    @Autowired
    private LocaleMessageSourceService messageSource;

    @Autowired
    private MiningOrderService miningOrderService;

    @Autowired
    private LockedOrderService lockedOrderService;

    @Autowired
    private MemberTransactionService memberTransactionService;

    @Autowired
    private CoinService coinService;

    @Autowired
    private SMSProvider smsProvider;

    @Value("${spark.system.md5.key}")
    private String md5Key;

    /**
     * 分页查询
     * @param pageModel
     * @return
     */
    @RequiresPermissions("activity:activity:page-query")
    @PostMapping("page-query")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "分页查看活动列表Activity")
    public MessageResult activityList(PageModel pageModel) {
        if (pageModel.getProperty() == null) {
            List<String> list = new ArrayList<>();
            list.add("createTime");
            List<Sort.Direction> directions = new ArrayList<>();
            directions.add(Sort.Direction.DESC);
            pageModel.setProperty(list);
            pageModel.setDirection(directions);
        }
        Page<Activity> all = activityService.findAll(null, pageModel.getPageable());
        return success(all);
    }
    @RequiresPermissions("activity:activity:locked-activity")
    @PostMapping("locked-activity")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "查看锁仓活动列表")
    public MessageResult lockedActivityList() {
        List<Activity> all = activityService.findByTypeAndStep(6, 1); //查询锁仓活动并且在进行中的
        return success(all);
    }

    /**
     * 添加活动信息
     * @param activity
     * @return
     */
    @RequiresPermissions("activity:activity:add")
    @PostMapping("add")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "新增活动信息Activity")
    public MessageResult ExchangeCoinList(
            @Valid Activity activity) {
        activity.setCreateTime(DateUtil.getCurrentDate());
        activity = activityService.save(activity);
        return MessageResult.getSuccessInstance(messageSource.getMessage("SUCCESS"), activity);
    }

    /**
     * 修改活动进度数值
     * @param id
     * @param progress
     * @return
     */
    @RequiresPermissions("activity:activity:modify-progress")
    @PostMapping("modify-progress")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "修改活动进度Activity")
    public MessageResult alterActivity(
            @RequestParam("id") Long id,
            @RequestParam("progress") Integer progress) {
        notNull(id, "validate id!");

        Activity result = activityService.findOne(id);
        notNull(result, "validate activity!");

        if (result.getProgress() > progress.intValue()) {
            return error("新进度数值小于当前数值");
        }
        result.setProgress(progress);

        activityService.save(result);

        return success(messageSource.getMessage("SUCCESS"));
    }

    /**
     * 修改活动冻结总资产
     * @param id
     * @param freezeAmount
     * @return
     */
    @RequiresPermissions("activity:activity:modify-freezeamount")
    @PostMapping("modify-freezeamount")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "修改活动冻结总资产Activity")
    public MessageResult alterActivityFreezeAmount(
            @RequestParam("id") Long id,
            @RequestParam("freezeAmount") BigDecimal freezeAmount) {
        notNull(id, "validate id!");

        Activity result = activityService.findOne(id);
        notNull(result, "validate activity!");

        if (result.getFreezeAmount().compareTo(freezeAmount) > 0) {
            return error("新冻结资产数量小于当前数值");
        }
        result.setFreezeAmount(freezeAmount);

        activityService.save(result);

        return success(messageSource.getMessage("SUCCESS"));
    }

    /**
     * 修改活动成交总数
     * @param id
     * @param tradedAmount
     * @return
     */
    @RequiresPermissions("activity:activity:modify-tradedamount")
    @PostMapping("modify-tradedamount")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "修改活动成交总数Activity")
    public MessageResult alterActivityTradedAmount(
            @RequestParam("id") Long id,
            @RequestParam("tradedAmount") BigDecimal tradedAmount) {
        notNull(id, "validate id!");

        Activity result = activityService.findOne(id);
        notNull(result, "validate activity!");

        if (result.getTradedAmount().compareTo(tradedAmount) > 0) {
            return error("新冻结资产数量小于当前数值");
        }
        result.setTradedAmount(tradedAmount);

        activityService.save(result);

        return success(messageSource.getMessage("SUCCESS"));
    }

    //Modify
    @RequiresPermissions("activity:activity:modify")
    @PostMapping("modify")
    @AccessLog(module = AdminModule.ACTIVITY, operation = "修改活动信息Activity")
    public MessageResult alterActivity(
            @RequestParam("id") Long id,
            @RequestParam(value = "title", required = false) String title,
            @RequestParam(value = "detail", required = false) String detail,
            @RequestParam(value = "status", required = false) Integer status,
            @RequestParam(value = "step", required = false) Integer step,
            @RequestParam(value = "type", required = false) Integer type,
            @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime,
            @RequestParam(value = "totalSupply", required = false) BigDecimal totalSupply,
            @RequestParam(value = "price", required = false) BigDecimal price,
            @RequestParam(value = "priceScale", required = false) Integer priceScale,
            @RequestParam(value = "unit", required = false) String unit,
            @RequestParam(value = "acceptUnit", required = false) String acceptUnit,
            @RequestParam(value = "amountScale", required = false) Integer amountScale,
            @RequestParam(value = "maxLimitAmount", required = false) BigDecimal maxLimitAmount,  //原项目中写成maxLimitAmout，此处改正为maxLimitAmount
            @RequestParam(value = "minLimitAmount", required = false) BigDecimal minLimitAmount,  //原项目中写成minLimitAmout，此处改正为minLimitAmount
            @RequestParam(value = "limitTimes", required = false) Integer limitTimes,
            @RequestParam(value = "settings", required = false) String settings,
            @RequestParam(value = "content", required = false) String content,
            @RequestParam(value = "smallImageUrl", required = false) String smallImageUrl,
            @RequestParam(value = "bannerImageUrl", required = false) String bannerImageUrl,
            @RequestParam(value = "noticeLink", required = false) String noticeLink,
            @RequestParam(value = "activityLink", required = false) String activityLink,
            @RequestParam(value = "leveloneCount", required = false) Integer leveloneCount, // L1数量
            @RequestParam(value = "holdLimit", required = false) BigDecimal holdLimit,
            @RequestParam(value = "holdUnit", required = false) String holdUnit,
            @RequestParam(value = "miningDays", required = false) Integer miningDays,
            @RequestParam(value = "miningDaysprofit", required = false) BigDecimal miningDaysprofit,
            @RequestParam(value = "miningUnit", required = false) String miningUnit,
            @RequestParam(value = "miningInvite", required = false) BigDecimal miningInvite,
            @RequestParam(value = "miningInvitelimit", required = false) BigDecimal miningInvitelimit,
            @RequestParam(value = "miningPeriod", required = false) Integer miningPeriod,
            @RequestParam(value = "lockedUnit", required = false) String lockedUnit,
            @RequestParam(value = "lockedPeriod", required = false) Integer lockedPeriod,
            @RequestParam(value = "lockedDays", required = false) Integer lockedDays,
            @RequestParam(value = "releaseType", required = false) Integer releaseType,
            @RequestParam(value = "releasePercent", required = false) BigDecimal releasePercent,
            @RequestParam(value = "lockedFee", required = false) BigDecimal lockedFee,
            @RequestParam(value = "releaseAmount", required = false) BigDecimal releaseAmount,
            @RequestParam(value = "releaseTimes", required = false) BigDecimal releaseTimes,

            @RequestParam(value = "password") String password,
            @SessionAttribute(SysConstant.SESSION_ADMIN) Admin admin) {
        password = Encrypt.MD5(password + md5Key);
        Assert.isTrue(password.equals(admin.getPassword()), messageSource.getMessage("WRONG_PASSWORD"));

        Activity result = activityService.findOne(id);

        notNull(result, "validate activity!");

        if (title != null) result.setTitle(title);
        if (detail != null) result.setDetail(detail);
        if (status != null) result.setStatus(status == 0 ? BooleanEnum.IS_FALSE : BooleanEnum.IS_TRUE);
        if (step != null) result.setStep(step);
        if (type != null) result.setType(type);
        if (startTime != null) result.setStartTime(startTime);
        if (endTime != null) result.setEndTime(endTime);
        if (totalSupply != null) result.setTotalSupply(totalSupply);
        if (price != null) result.setPrice(price);
        if (priceScale != null) result.setPriceScale(priceScale);
        if (unit != null) result.setUnit(unit);
        if (acceptUnit != null) result.setAcceptUnit(acceptUnit);
        if (amountScale != null) result.setAmountScale(amountScale);
        if (maxLimitAmount != null) result.setMaxLimitAmout(maxLimitAmount);
        if (minLimitAmount != null) result.setMinLimitAmout(minLimitAmount);
        if (limitTimes != null) result.setLimitTimes(limitTimes);
        if (settings != null) result.setSettings(settings);
        if (content != null) result.setContent(content);
        if (smallImageUrl != null) result.setSmallImageUrl(smallImageUrl);
        if (bannerImageUrl != null) result.setBannerImageUrl(bannerImageUrl);
        if (noticeLink != null) result.setNoticeLink(noticeLink);
        if (activityLink != null) result.setActivityLink(activityLink);
        if (leveloneCount != null) result.setLeveloneCount(leveloneCount);
        if (holdLimit != null) result.setHoldLimit(holdLimit);
        if (holdUnit != null) result.setHoldUnit(holdUnit);
        if (miningDays != null) result.setMiningDays(miningDays);
        if (miningDaysprofit != null) result.setMiningDaysprofit(miningDaysprofit);
        if (miningUnit != null) result.setMiningUnit(miningUnit);
        if (miningInvite != null) result.setMiningInvite(miningInvite);
        if (miningInvitelimit != null) result.setMiningInvitelimit(miningInvitelimit);
        if (miningPeriod != null) result.setMiningPeriod(miningPeriod);
        if (lockedUnit != null) result.setLockedUnit(lockedUnit);
        if (lockedPeriod != null) result.setLockedPeriod(lockedPeriod);
        if (lockedDays != null) result.setLockedDays(lockedDays);
        if (releaseType != null) result.setReleaseType(releaseType);
        if (releasePercent != null) result.setReleasePercent(releasePercent);
        if (lockedFee != null) result.setLockedFee(lockedFee);
        if (releaseAmount != null) result.setReleaseAmount(releaseAmount);
        if (releaseTimes != null) result.setReleaseTimes(releaseTimes);

        activityService.saveAndFlush(result);
        return success(messageSource.getMessage("SUCCESS"));
    }

    @RequiresPermissions("activity:activity:detail")
    @GetMapping("{id}/detail")
    public MessageResult detail(
            @PathVariable("id") Long id) {
        Activity activity = activityService.findById(id);
        Assert.notNull(activity, "validate id!");
        return success(activity);
    }















}

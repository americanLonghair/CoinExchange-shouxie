package com.bizzan.bitrade.model.screen;

import lombok.Data;

@Data
public class AccountScreen {

    private String account ;
}
